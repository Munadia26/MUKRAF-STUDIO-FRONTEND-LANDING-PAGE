module.exports=[69047,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bslug%5D_page_actions_ee459282.js.map