module.exports=[17362,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_%5Btitle%5D_page_actions_6bb64dd3.js.map