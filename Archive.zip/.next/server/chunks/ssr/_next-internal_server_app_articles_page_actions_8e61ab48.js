module.exports=[77611,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_page_actions_8e61ab48.js.map