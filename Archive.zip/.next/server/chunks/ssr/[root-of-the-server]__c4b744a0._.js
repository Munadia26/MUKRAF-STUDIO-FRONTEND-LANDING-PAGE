module.exports=[9270,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.AppRouterContext},36313,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.HooksClientContext},18341,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored.contexts.ServerInsertedHtml},38783,(a,b,c)=>{"use strict";b.exports=a.r(42602).vendored["react-ssr"].ReactServerDOMTurbopackClient},56704,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},20635,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24361,(a,b,c)=>{b.exports=a.x("util",()=>require("util"))},14747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))},13749,a=>{"use strict";let b=(0,a.i(70106).default)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);a.s(["ChevronLeft",()=>b],13749)},7943,41675,a=>{"use strict";var b=a.i(33217),c=a.i(83490);a.s(["useArticles",0,()=>(0,b.useQuery)({queryKey:["articles"],queryFn:async()=>{let{data:a}=await c.default.get("https://api.mukraf-akkdev.com/api/v1/articles");return a.data}})],7943);let d=(0,a.i(70106).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);a.s(["Calendar",()=>d],41675)},87532,a=>{"use strict";let b=(0,a.i(70106).default)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);a.s(["Search",()=>b],87532)},33350,a=>{"use strict";let b=(0,a.i(70106).default)("tag",[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",key:"vktsd0"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor",key:"kqv944"}]]);a.s(["Tag",()=>b],33350)},44622,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(7943),e=a.i(72131),f=a.i(87532),g=a.i(41675),h=a.i(38246);function i({activeTitle:a}){let{data:c}=(0,d.useArticles)(),[i,j]=(0,e.useState)(""),k=(c||[]).filter(b=>b.title.toLowerCase().includes(i.toLowerCase())&&b.title!==a).slice(0,5);return(0,b.jsxs)("div",{className:"space-y-10 sticky top-32",children:[(0,b.jsxs)("div",{className:"bg-gray-50 p-8 rounded-[2rem] border border-gray-100",children:[(0,b.jsx)("h4",{className:"text-[10px] font-black uppercase text-[#1e3a5f] mb-4 tracking-widest",children:"Cari Artikel"}),(0,b.jsxs)("div",{className:"relative",children:[(0,b.jsx)("input",{type:"text",placeholder:"Ketik judul...",value:i,onChange:a=>j(a.target.value),className:"w-full bg-white border border-gray-200 rounded-xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/20"}),(0,b.jsx)(f.Search,{className:"absolute right-4 top-3.5 text-gray-400",size:16})]})]}),(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsx)("h4",{className:"text-[10px] font-black uppercase text-[#1e3a5f] px-2 tracking-widest",children:"Artikel Lainnya"}),(0,b.jsx)("div",{className:"grid gap-6",children:k.length>0?k.map(a=>(0,b.jsxs)(h.default,{href:`/articles/${a.title.toLowerCase().replace(/ /g,"-")}`,className:"group flex gap-4 items-center",children:[(0,b.jsx)("div",{className:"w-20 h-20 rounded-xl overflow-hidden shrink-0 border border-gray-100",children:(0,b.jsx)("img",{src:`https://api.mukraf-akkdev.com/uploads/${a.image}`,alt:a.title,className:"w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"})}),(0,b.jsxs)("div",{className:"space-y-1",children:[(0,b.jsx)("h5",{className:"text-[11px] font-black text-[#1e3a5f] uppercase italic line-clamp-2 leading-tight group-hover:text-cyan-600 transition-colors",children:a.title}),(0,b.jsxs)("div",{className:"flex items-center gap-1.5 text-[9px] font-bold text-gray-400",children:[(0,b.jsx)(g.Calendar,{size:10,className:"text-cyan-500"}),(0,b.jsx)("span",{children:new Date(a.createdAt).toLocaleDateString("id-ID",{day:"numeric",month:"short"})})]})]})]},a.id)):(0,b.jsx)("p",{className:"text-[10px] italic text-gray-400 px-2",children:"Tidak ada artikel lain ditemukan."})})]})]})}var j=a.i(73885),k=a.i(56283),l=a.i(13749),m=a.i(33350);function n(){var a;let{title:e}=(0,c.useParams)(),{data:f,isLoading:n}=(0,d.useArticles)(),o=(f||[]).find(a=>a.title.toLowerCase().replace(/[^a-z0-9\s]/g,"").replace(/\s+/g,"-").trim()===e);if(n)return(0,b.jsx)("div",{className:"min-h-screen flex items-center justify-center font-black bg-[#0a1628] text-white tracking-[0.4em] text-xs",children:"SINKRONISASI DATA..."});if(!o)return(0,b.jsx)("div",{className:"min-h-screen flex items-center justify-center font-black text-red-500 bg-[#0a1628]",children:"ARTIKEL TIDAK DITEMUKAN"});encodeURIComponent(`Halo Mukraf, saya tertarik berkonsultasi setelah membaca artikel: ${o.title}`);let p=(a=o.description)?a:"";return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(j.default,{}),(0,b.jsxs)("main",{className:"bg-white min-h-screen",children:[(0,b.jsxs)("section",{className:"relative pt-48 pb-16 px-6 md:px-10 bg-[#0a1628] overflow-hidden",children:[(0,b.jsx)("div",{className:"absolute top-20 right-0 w-[500px] h-[500px] rounded-full bg-cyan-500/5 blur-3xl pointer-events-none"}),(0,b.jsx)("div",{className:"absolute top-1/2 left-0 w-[300px] h-[300px] rounded-full bg-blue-500/5 blur-2xl pointer-events-none"}),(0,b.jsxs)("div",{className:"max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10",children:[(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsx)("h1",{className:"text-2xl md:text-4xl font-black text-white uppercase tracking-tight italic leading-tight",children:o.title}),(0,b.jsxs)("div",{className:"flex items-center gap-6 text-gray-400 font-bold text-[10px] uppercase tracking-widest",children:[(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsx)(g.Calendar,{size:14,className:"text-cyan-500"}),(0,b.jsx)("span",{children:new Date(o.createdAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})})]}),(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsx)(m.Tag,{size:14,className:"text-cyan-500"}),(0,b.jsx)("span",{children:"Mukraf Insight"})]})]})]}),(0,b.jsx)("div",{className:"flex flex-col sm:flex-row items-center lg:justify-end gap-4 mb-2 w-full",children:(0,b.jsxs)("a",{href:`https://wa.me/628157642627?text=${encodeURIComponent("Halo Mukraf")}`,target:"_blank",rel:"noopener noreferrer",className:"w-full sm:w-auto px-10 py-5 bg-cyan-500/10 hover:bg-cyan-500/20 border-2 border-cyan-500/30 hover:border-cyan-400 text-white rounded-full font-black text-[10px] uppercase tracking-[0.2em] transition-all duration-300 text-center flex items-center justify-center gap-3 group relative overflow-hidden shadow-[0_0_20px_rgba(6,182,212,0.15)] hover:shadow-[0_0_30px_rgba(6,182,212,0.3)]",children:[(0,b.jsx)("div",{className:"absolute inset-0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/10 to-transparent"}),(0,b.jsx)("svg",{viewBox:"0 0 24 24",className:"w-5 h-5 fill-cyan-400 group-hover:scale-110 group-hover:drop-shadow-[0_0_8px_rgba(34,211,238,0.8)] transition-all",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.15 11.891c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"})}),(0,b.jsx)("span",{className:"relative z-10",children:"Konsultasi Gratis Sekarang!"})]})})]}),(0,b.jsx)("div",{className:"absolute bottom-0 left-0 w-full overflow-hidden leading-none pointer-events-none",children:(0,b.jsxs)("svg",{viewBox:"0 0 1440 90",xmlns:"http://www.w3.org/2000/svg",preserveAspectRatio:"none",className:"w-full h-16 md:h-24",children:[(0,b.jsx)("path",{d:"M0,30 C240,90 480,0 720,45 C960,90 1200,10 1440,50 L1440,90 L0,90 Z",fill:"white",opacity:"0.3"}),(0,b.jsx)("path",{d:"M0,50 C200,10 440,80 720,35 C1000,0 1240,70 1440,40 L1440,90 L0,90 Z",fill:"white",opacity:"0.6"}),(0,b.jsx)("path",{d:"M0,65 C180,30 400,75 660,55 C900,35 1200,75 1440,60 L1440,90 L0,90 Z",fill:"white"})]})})]}),(0,b.jsx)("section",{className:"pb-24 px-6 md:px-10 pt-14",children:(0,b.jsxs)("div",{className:"max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-16 items-start",children:[(0,b.jsxs)("div",{className:"w-full min-w-0",children:[(0,b.jsx)("div",{className:"w-full overflow-hidden rounded-[2.5rem] shadow-2xl border border-gray-100 bg-gray-50 mb-12",children:(0,b.jsx)("img",{src:`https://api.mukraf-akkdev.com/uploads/${o.image}`,alt:o.title,className:"w-full h-auto object-cover max-h-[600px]"})}),(0,b.jsx)("style",{children:`
                /* Alignment dari admin */
                .ql-align-center  { text-align: center; }
                .ql-align-right   { text-align: right; }
                .ql-align-justify { text-align: justify; }
                .ql-align-left    { text-align: left; }

                /* Word wrap - kata tidak terpotong */
                .article-body {
                  width: 100%;
                  max-width: 100%;
                  overflow: hidden;
                  box-sizing: border-box;
                  overflow-wrap: break-word;
                  word-break: normal;
                  word-wrap: break-word;
                }
                .article-body p,
                .article-body li,
                .article-body h1,
                .article-body h2,
                .article-body h3,
                .article-body h4,
                .article-body span,
                .article-body td {
                  overflow-wrap: break-word;
                  word-break: normal;
                  word-wrap: break-word;
                  max-width: 100%;
                  box-sizing: border-box;
                }
                .article-body a {
                  overflow-wrap: anywhere;
                  word-break: break-all;
                }

                /* Gambar dari editor Quill - tampil penuh */
                .article-body img {
                  max-width: 100% !important;
                  width: auto;
                  height: auto;
                  display: block;
                  margin: 1.25rem auto;
                  border-radius: 0.5rem;
                }
                .article-body video,
                .article-body iframe {
                  max-width: 100% !important;
                  width: 100%;
                  height: auto;
                  aspect-ratio: 16 / 9;
                  display: block;
                  margin: 1.25rem auto;
                  border-radius: 0.5rem;
                }

                /* Code block */
                .article-body pre,
                .article-body code {
                  white-space: pre-wrap;
                  overflow-x: hidden;
                  overflow-wrap: break-word;
                  word-break: normal;
                }

                /* Quill indent */
                .article-body .ql-indent-1 { padding-left: 1.5rem; }
                .article-body .ql-indent-2 { padding-left: 3rem; }
                .article-body .ql-indent-3 { padding-left: 4.5rem; }
              `}),(0,b.jsx)("div",{className:"w-full min-w-0 overflow-hidden",children:(0,b.jsx)("div",{className:"max-w-full",children:(0,b.jsx)("div",{className:" article-body [&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:my-6  [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:my-6  [&_li]:my-2 [&_li]:text-gray-700  [&_p]:text-gray-600 [&_p]:leading-relaxed  [&_h1]:text-3xl [&_h1]:font-black [&_h1]:uppercase  [&_h2]:text-2xl [&_h2]:font-black  [&_h3]:text-xl [&_h3]:font-bold ",dangerouslySetInnerHTML:{__html:p}})})}),(0,b.jsx)("div",{className:"w-full mt-16 pt-8 border-t border-gray-100",children:(0,b.jsxs)(h.default,{href:"/articles",className:"inline-flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-[#1e3a5f] hover:text-cyan-500 transition-all",children:[(0,b.jsx)(l.ChevronLeft,{size:18}),"Kembali ke Katalog Artikel"]})})]}),(0,b.jsx)("aside",{className:"w-full min-w-0",children:(0,b.jsx)("div",{className:"sticky top-28 max-h-[calc(100vh-7rem)] overflow-y-auto",children:(0,b.jsx)(i,{activeTitle:o.title})})})]})})]}),(0,b.jsx)(k.default,{})]})}a.s(["default",()=>n],44622)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c4b744a0._.js.map